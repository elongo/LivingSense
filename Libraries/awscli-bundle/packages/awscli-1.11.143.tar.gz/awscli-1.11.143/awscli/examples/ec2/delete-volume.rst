**To delete a volume**

This example command deletes an available volume with the volume ID of ``vol-049df61146c4d7901``. If the command succeeds, no output is returned.

Command::

  aws ec2 delete-volume --volume-id vol-049df61146c4d7901
