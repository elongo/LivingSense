
Tag->type map
-------------

.. autoclass:: pyasn1.type.tagmap.TagMap
   :members:
